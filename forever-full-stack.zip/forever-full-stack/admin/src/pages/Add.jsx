import React, { useState } from 'react';
import axios from 'axios';
import { backendUrl } from '../App';
import { toast } from 'react-toastify';

const Add = ({ token }) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [stipend, setStipend] = useState("");
  const [skillsRequired, setSkillsRequired] = useState("");
  const [registrationDeadline, setRegistrationDeadline] = useState("");
  const [courseDuration, setCourseDuration] = useState("");

  const onSubmitHandler = async (e) => {
    e.preventDefault();

    try {
      const gigData = {
        title,
        description,
        stipend,
        skillsRequired,
        registrationDeadline,
        courseDuration,
      };

      const response = await axios.post(backendUrl + "/api/gig/add", gigData, { headers: { token } });

      if (response.data.success) {
        toast.success(response.data.message);
        setTitle('');
        setDescription('');
        setStipend('');
        setSkillsRequired('');
        setRegistrationDeadline('');
        setCourseDuration('');
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error(error.message);
    }
  };

  return (
    <form onSubmit={onSubmitHandler} className='flex flex-col w-full items-start gap-3'>

      <div className='w-full'>
        <p className='mb-2'>Title</p>
        <input onChange={(e) => setTitle(e.target.value)} value={title} className='w-full max-w-[500px] px-3 py-2' type="text" placeholder='Gig title' required />
      </div>

      <div className='w-full'>
        <p className='mb-2'>Description</p>
        <textarea onChange={(e) => setDescription(e.target.value)} value={description} className='w-full max-w-[500px] px-3 py-2' placeholder='Gig description' required />
      </div>

      <div className='w-full'>
        <p className='mb-2'>Skills Required (comma separated)</p>
        <input onChange={(e) => setSkillsRequired(e.target.value)} value={skillsRequired} className='w-full max-w-[500px] px-3 py-2' type="text" placeholder='e.g. React, Python, UI/UX' required />
      </div>

      <div className='w-full'>
        <p className='mb-2'>Stipend</p>
        <input onChange={(e) => setStipend(e.target.value)} value={stipend} className='w-full max-w-[500px] px-3 py-2' type="number" placeholder='Enter stipend amount' required />
      </div>

      <div className='w-full'>
        <p className='mb-2'>Registration Deadline</p>
        <input onChange={(e) => setRegistrationDeadline(e.target.value)} value={registrationDeadline} className='w-full max-w-[500px] px-3 py-2' type="date" required />
      </div>

      <div className='w-full'>
        <p className='mb-2'>Course Duration (in weeks)</p>
        <input onChange={(e) => setCourseDuration(e.target.value)} value={courseDuration} className='w-full max-w-[500px] px-3 py-2' type="number" placeholder='Enter duration' required />
      </div>

      <button type="submit" className='w-28 py-3 mt-4 bg-black text-white'>Add Gig</button>
    </form>
  );
};

export default Add;
