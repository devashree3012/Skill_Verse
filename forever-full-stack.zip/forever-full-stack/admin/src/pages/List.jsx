import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { backendUrl } from '../App';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const List = ({ token }) => {
  const [gigs, setGigs] = useState([]);
  const [selectedGig, setSelectedGig] = useState(null);
  const navigate = useNavigate();

  const fetchGigs = async () => {
    try {
      const response = await axios.get(backendUrl + '/api/gig/list');
      if (response.data.success) {
        setGigs(response.data.gigs.reverse());
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error(error.message);
    }
  };

  const handleGigClick = (gig) => {
    setSelectedGig(selectedGig?.id === gig.id ? null : gig);
  };

  const handleApprove = async (studentId) => {
    try {
      const response = await axios.post(
        backendUrl + '/api/gig/approve',
        { gigId: selectedGig.id, studentId },
        { headers: { token } }
      );
      if (response.data.success) {
        toast.success('Student approved!');
        fetchGigs();
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error(error.message);
    }
  };

  const handleReject = async (studentId) => {
    try {
      const response = await axios.post(
        backendUrl + '/api/gig/reject',
        { gigId: selectedGig.id, studentId },
        { headers: { token } }
      );
      if (response.data.success) {
        toast.success('Student rejected.');
        fetchGigs();
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error(error.message);
    }
  };

  useEffect(() => {
    fetchGigs();
  }, []);

  return (
    <>
      <p className='mb-2 font-bold text-lg'>All Gigs List</p>
      <div className='flex flex-col gap-2'>

        {/* ------- List Table Title ---------- */}
        <div className='hidden md:grid grid-cols-[2fr_3fr_1fr] items-center py-2 px-2 border bg-gray-100 text-sm font-semibold'>
          <b>Title</b>
          <b>Description</b>
          <b>No. of Applicants</b>
        </div>

        {/* ------ Gig List ------ */}
        {gigs.map((gig, index) => (
          <div key={index} className='border p-3'>
            <div
              className='grid grid-cols-[2fr_3fr_1fr] items-center cursor-pointer'
              onClick={() => handleGigClick(gig)}
            >
              <p className='font-bold text-blue-600 hover:underline'>{gig.title}</p>
              <p>{gig.description.substring(0, 50)}...</p>
              <p className='text-center font-semibold'>{gig.applicants.length}</p>
            </div>

            {/* ------ Applicants List (Shown when gig is clicked) ------ */}
            {selectedGig?.id === gig.id && (
              <div className='mt-3 p-2 border-t'>
                <p className='font-bold mb-2'>Applicants</p>
                {gig.applicants.length > 0 ? (
                  gig.applicants.map((student, i) => (
                    <div key={i} className='flex justify-between items-center p-2 border rounded-lg'>
                      <p
                        className='text-blue-500 cursor-pointer hover:underline'
                        onClick={() => navigate(`/student/${student.id}`)}
                      >
                        {student.name}
                      </p>
                      <div className='flex gap-2'>
                        <button
                          className='px-3 py-1 bg-green-500 text-white rounded'
                          onClick={() => handleApprove(student.id)}
                        >
                          Approve
                        </button>
                        <button
                          className='px-3 py-1 bg-red-500 text-white rounded'
                          onClick={() => handleReject(student.id)}
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className='text-gray-500 italic'>No applicants yet.</p>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  );
};

export default List;
